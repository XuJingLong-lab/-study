package memory;

import java.io.*;
/*
* 此时的代码实质上就是在内存里面专门开辟了一块内存空间进行数据的io处理，本次实现了io处理又没有产生任何文件
* 所以对于那些临时的操作文件要基于io形式完成，可以采用内存流处理
*
* 在内存流之中ByteArrayOutputStream类中有一个方法非常有意义：public byte[] toBytrArray(),
* 将所有保存在内存输出流的数据全部以字节数组的形式返回
* */
public class MemoryStream {
    public static void main(String[] args) throws IOException {
        // 设置要处理的操作数据，等于此时先把内容通过程序输出到内存输入流里面
        InputStream in = new ByteArrayInputStream("xuglonjing".getBytes());
        OutputStream out = new ByteArrayOutputStream();
        // data不是数组，读取单个内容
        int data = 0;
        while((data = in.read()) != -1){ // 获取内存输入流中的数据后，将数据全部放到内存输出流中转大写
            out.write(Character.toUpperCase(data));
        }
        System.out.println(out.toString()); // 打印内存输出流取出的数据
        out.close();
        in.close();

    }
}
