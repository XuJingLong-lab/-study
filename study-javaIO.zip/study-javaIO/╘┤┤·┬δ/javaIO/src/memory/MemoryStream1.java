package memory;

import java.io.*;

/*
* 使用内存输出流读取文件的全部内容
*
* 如果面对数据量较大的时候，要想将数据全部读取进来，实际上就必须利用内存的输出流进行操作，
* 即：分批将数据保存到内存输出流中，读取完成后再去使用“toByteArray()”方法取出全部内容
* */
public class MemoryStream1 {
    public static void main(String[] args) throws IOException {
        InputStream in = new FileInputStream(new File("d:"+File.separator+"parent"+File.separator+"111.png"));
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] data = new byte[1024];
        int len = 0;
        while((len = in.read(data)) != -1){
            byteArrayOutputStream.write(data,0,len);
        }
        System.out.println(new String(byteArrayOutputStream.toByteArray()));
        in.close();
        byteArrayOutputStream.close();
    }
}
