package pipe;


import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

public class PipeDemo {
    public static void main(String[] args) throws IOException {
        SendThread send = new SendThread();
        ReceiveThread receive = new ReceiveThread();

        send.getOut().connect(receive.getIn()); // 管道对接

        new Thread(send).start();
        new Thread(receive).start();
    }
}


class SendThread implements Runnable{
    private PipedOutputStream out = new PipedOutputStream();
    @Override
    public void run() {
        try {
            this.out.write("徐京龙太帅了".getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public PipedOutputStream getOut() {

        return out;
    }
}


class ReceiveThread implements Runnable{
    private PipedInputStream in = new PipedInputStream();
    @Override
    public void run() {
        byte[] data = new byte[1024];
        try {
            int len = this.in.read(data);
            System.out.println("收到的数据为：" + new String(data,0,len));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public PipedInputStream getIn() {
        return in;
    }
}