package print;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class PrintWriterDemo {
    public static void main(String[] args) throws FileNotFoundException {
        PrintWriter pw = new PrintWriter(new FileOutputStream(new File("D:" + File.separator + "parent" + File.separator + "demo.txt" )));
        pw.println("徐京龙世界第一帅,帅到爆！");

        // 格式化输出
        String name = "徐京龙";
        int age = 20;
        String desc = "中国最帅";
        pw.printf("姓名：%s\n年龄：%d\n描述：%s",name,age,desc);
        pw.close();
    }
}
