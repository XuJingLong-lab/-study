package print;

import java.io.*;

// 设计一个打印流的功能类，该类支持各种数据类型输出流处理
class PrintUtil implements Closeable {
    private OutputStream out;
    public PrintUtil(OutputStream out){ // 初始化out，输出的类型
        this.out = out;
    }

    public void print(String str) throws IOException {
        this.out.write(str.getBytes());
    }
    public void println(String str) throws IOException { // 换行输出字符串
        this.print(str+"\r\n");
    }
    public void print(int num) throws IOException {
        this.print(String.valueOf(num));
    }
    public void println(int num) throws IOException {
        this.println(String.valueOf(num));
    }

    @Override
    public void close() throws IOException {
        this.out.close();
    }
}


public class PrintDemo {
    public static void main(String[] args) throws IOException {
        PrintUtil pu = new PrintUtil(new FileOutputStream(new File("D:" + File.separator + "parent" + File.separator + "demo.txt" )));
        pu.print("徐京龙世界第一帅");
        pu.close();
    }
}
