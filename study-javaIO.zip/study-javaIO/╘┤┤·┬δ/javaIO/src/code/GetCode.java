package code;

public class GetCode {
    public static void main(String[] args) {
        System.getProperties().list(System.out);
    }
}
