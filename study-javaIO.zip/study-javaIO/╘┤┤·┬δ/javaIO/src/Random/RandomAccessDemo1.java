package Random;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessDemo1 {
    public static void main(String[] args) throws IOException {
        File f = new File("D:" + File.separator + "parent" + File.separator + "demo.txt");

        RandomAccessFile ran = new RandomAccessFile(f,"r");
        {
            // 读取"lisi"数据
            ran.skipBytes(12); // 姓名8位，年龄4位。12的整数倍。
            byte[] data = new byte[8];
            ran.read(data);
            System.out.println(String.format("姓名：%s，年龄：%s", new String(data), ran.readInt()));
        }
        {
            // 读取"张三"数据
            ran.seek(0); // 跳回到哪个位置。
            byte[] data = new byte[8];
            ran.read(data);
            System.out.println(String.format("姓名：%s，年龄：%s", new String(data), ran.readInt()));
        }
        {
            // 读取"wangwu"数据
            ran.skipBytes(12); // 读完张三时，指针已经到了12，再跳12位才可以读到王五
            byte[] data = new byte[8];
            ran.read(data);
            System.out.println(String.format("姓名：%s，年龄：%s", new String(data), ran.readInt()));
        }
    }
}
