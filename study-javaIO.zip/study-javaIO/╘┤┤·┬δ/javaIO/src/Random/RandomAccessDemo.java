package Random;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
// 写
public class RandomAccessDemo {
    public static void main(String[] args) throws IOException {
        File f = new File("D:" + File.separator + "parent" + File.separator + "demo.txt");

        String[] names = new String[]{"zhangsan","lisi    ","wangwu  ","xiaoming",};
        int[] ages = new int[]{17,19,18,17};

        RandomAccessFile ran = new RandomAccessFile(f,"rw"); // “rw”是模式，表示可读可写

        for(int i = 0; i < names.length; i++){
            ran.write(names[i].getBytes()); // 写入字符串
            ran.writeInt(ages[i]); // 写入数字 writInt()默认给数字占4位
        }
        ran.close();

    }
}
