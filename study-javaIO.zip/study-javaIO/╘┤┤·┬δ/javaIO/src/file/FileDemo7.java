package file;

import java.io.File;

// file文件修改文件名
public class FileDemo7 {
    public static void main(String[] args) {
        File oldFile = new File("d:"+File.separator+"parent"+File.separator+"1.png");
        File newFile = new File("d:"+File.separator+"parent"+File.separator+"111.png");
        oldFile.renameTo(newFile);
    }
}
