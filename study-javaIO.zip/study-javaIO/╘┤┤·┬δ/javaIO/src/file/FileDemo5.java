package file;

import java.io.File;
import java.util.Arrays;
// 获取目录信息
public class FileDemo5 {
    public static void main(String[] args) {
        File file = new File("d:" + File.separator);
        /*
        * list() 此时只是列出了当前路径下的所有子路径，子路径可能是一个文件或者是一个目录，
        * 不存在父路径。
         */
//        System.out.println(Arrays.toString(file.list()));

        /*
        * listFiles() 包含了完整的路径信息
        * */
//        System.out.println(Arrays.toString(file.listFiles()));

        File f1 = new File("d:" + File.separator + "parent" + File.separator + "11");
        f1.delete();
    }
}
