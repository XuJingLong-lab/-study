package file;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileDemo8 {
//    public static void main(String[] args) throws IOException {
//        File fileDir = new File("D:"+File.separator+"parent"+File.separator+"info");
//        for(int i = 0; i < 100; i++){
//            File ff = new File(fileDir, "log-" + getTimestamp() + "-" + i + ".txt");
//            ff.createNewFile();
//            // 此时由于初期代码设计的失误缺少了补0操作，导致文件名称长度不一致，而且此时该目录下还有其他的文件信息
//            // 要求：不影响其他文件的情况下，完成补0操作
//
//        }
//
//    }
//        public static String getTimestamp(){
//            return new SimpleDateFormat("yyyyMMdd").format(new Date());
//
//        }

    public static void main(String[] args) {
        File fileDir = new File("d:"+File.separator+"parent"+File.separator+"info");
        rename(fileDir);

    }


    public static void rename(File file){ // 需要考虑子目录
        int max = 0;
        if(file.isDirectory()){ // 判断是否为目录
            File[] files = file.listFiles(); // 列出所有子目录的路径
            if(files != null){
                for(int i = 0; i < files.length; i++){
                    rename(files[i]);
                }
            }
        }else{ // 进行文件修改
            if(file.isFile()) {
                if (file.getName().matches("log\\-\\d{8}\\-\\d+\\.txt")) { // 要修改的路径信息
//                System.out.println(file.getName());
                    String path = file.getAbsolutePath();
                    String subName = path.substring(0, path.lastIndexOf("\\") + 1);
                    max = getMaxLength(new File(subName));
                    if (file.getName().length() < max) {
                        String name = getZeroName(file.getName(), max);

                        File newFile = new File(subName, name);
                        file.renameTo(newFile);

                    }
                }
            }
        }

    }
    public static int getMaxLength(File file){ // 获取最大文件名称
        int maxlength = 0;
        File[] files = file.listFiles();
        for(File f:files){
            if(f.getName().length() > maxlength){
                maxlength = f.getName().length();
            }
        }
        return maxlength;
    }
    public static String getZeroName(String name, int max){ // 对文件名进行补0

        String subName = name.substring(name.lastIndexOf("-") + 1, name.lastIndexOf("."));
        for(int i = 0; i < max - name.length(); i++){ // 计算要补多少个0
            subName = "0" + subName;
        }
        String newName = name.substring(0,name.lastIndexOf("-")+1) + subName + ".txt";

        return newName;
    }

}
