package file;

import java.io.File;
import java.io.IOException;
/*
* file的构造方法
* */
public class FileDemo1 {
    public static void main(String[] args) throws IOException {
        /*
        * 在使用File类指派操作文件的时候，该路径可能不存在，只要不进行各种信息的获取操作，
        * 实际上是不会有任何问题的，只是单纯的表示一个要操作的文件路径。
        **/
        /*
        * createNewFile()，可以创建文件
        * */
        File f = new File("d:\\demo.txt");
        System.out.println(f.createNewFile());
    }
}
