package file;

import java.io.File;
// 创建目录
public class FileDemo3 {
    private static File f = new File("d:"+File.separator+"parent"+File.separator+"demo.txt");

    static { // 静态代码块，只执行一次，而且执行顺序比main函数还高。

        if(!f.getParentFile().exists()){ // 父路径不存在
            f.getParentFile().mkdirs(); // 创建所有的父目录
        }
    }
    public static void main(String[] args) throws Exception {

        if(f.exists()){
            System.out.println("文件存在，执行删除操作");
            f.delete();
        }else{
            System.out.println("文件不存在，执行创建操作");
            f.createNewFile();
        }
    }
}
