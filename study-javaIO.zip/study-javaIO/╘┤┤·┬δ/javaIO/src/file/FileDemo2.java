package file;

import java.io.File;

/*
* 文件的创建和删除
* */
public class FileDemo2 {
    public static void main(String[] args) throws Exception {
//        File f = new File("d:"+File.separator+"parent"+File.separator+"demo.txt"); // 报错
        File f = new File("d:"+File.separator+"demo.txt");
        if(f.exists()){
            System.out.println("文件存在，执行删除操作");
            f.delete();
        }else{
            System.out.println("文件不存在，执行创建操作");
            f.createNewFile();
        }
    }
}
