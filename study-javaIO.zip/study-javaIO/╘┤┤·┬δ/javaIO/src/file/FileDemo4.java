package file;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
// 获取文件信息
public class FileDemo4 {
    private static File f = new File("d:"+File.separator+"parent"+File.separator+"demo.txt");

    static { // 静态代码块，只执行一次，而且执行顺序比main函数还高。

        if(!f.getParentFile().exists()){ // 父路径不存在
            f.getParentFile().mkdirs(); // 创建所有的父目录
        }
    }
    public static void main(String[] args) throws Exception {

        if(f.exists()){
            System.out.println("文件是否能执行：" + f.canExecute());
            System.out.println("文件是否可写：" + f.canWrite());
            System.out.println("文件是否可读：" + f.canRead());
            System.out.println("文件的绝对路径(file对象)：" + f.getAbsoluteFile());
            System.out.println("文件的绝对路径(string字符串)：" + f.getAbsolutePath());
            System.out.println("文件名称：" + f.getName());
            System.out.println("当前路径是否为目录：" + f.isDirectory());
            System.out.println("当前路径是否为文件：" + f.isFile());
            System.out.println("获取最后一次的修改日期：" + new SimpleDateFormat
                    ("yyyy-MM-dd HH:mm:ss").format(new Date(f.lastModified())));
        }

        File file = new File("D:" + File.separator + "parent" + File.separator + "1.png");
        System.out.println("文件大小为：" + file.length());
    }
}
