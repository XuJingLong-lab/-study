package file;

import java.io.File;

public class FileDemo6 {
    public static void main(String[] args) {
        listDir(new File("d:"+File.separator));
    }

    public static void listDir(File file){
        if(file.isDirectory()){ // 当前路径是一个目录
            File[] files = file.listFiles(); // 列出当前目录的组成
                if(files != null) { // 确定已经列出了内容
                    for (int i = 0; i < files.length; i++) {
                        listDir(files[i]);
                    }
            }
        }
        System.out.println(file);

    }

}
