package stream;

import java.io.*;

public class ReaderDemo {
    public static void main(String[] args) throws IOException {
        // 1.读取文件的路径
        File file = new File("D:" + File.separator + "parent" + File.separator + "demo.txt" );
        if(file.exists()) {
            try(Reader reader = new FileReader(file)){ // 2.将实例化Reader放到try里面
                // 3.读取内容
                char[] date = new char[1024];
                int len = reader.read(date);
                System.out.println(new String(date,0,len));

            }catch(Exception e){ // 不用close()了，可以自动关闭

            }


        }
    }
}
