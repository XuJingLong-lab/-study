package stream;

import java.io.*;

public class CopyDemo {
    public static void main(String[] args) {
        CopyUtil cu = new CopyUtil(args);
        long time = 0;
        try {
            time = cu.copy();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(time);

    }
}
class CopyUtil{ // 定义一个专门实现拷贝的工具类
    private File srcFile; // 拷贝的源文件路径
    private File desFile; // 拷贝的目标文件路径

    public CopyUtil(String[] args){
        if(args.length != 2){
            System.out.println("错误，输入参数格式为：拷贝的源文件目录，拷贝的目标文件目录");
            System.exit(1); // 程序结束
        }
        this.srcFile = new File(args[0]);
        this.desFile = new File(args[1]);
    }
    /**
     * 实现拷贝的操作处理
     * @return 返回本次拷贝所花的时间,如果拷贝失败，则会有如下结果返回
     * -1：表示源文件不存在
     *-2：表示目标文件无法拷贝
     * */
    public long copy() throws IOException {
        long start = System.currentTimeMillis();
        if(!this.srcFile.exists()){ // 如果文件不存在
            throw new FileNotFoundException("源文件不存在"); // return -1;
        }
        if(!this.desFile.getParentFile().exists()){
            this.desFile.getParentFile().mkdirs(); // 创建目标父目录
        }
        InputStream in = null;
        OutputStream out = null;

        try{
            in = new FileInputStream(srcFile);
            out = new FileOutputStream(desFile);

            byte[] date = new byte[1024]; // 每次读取1024个内容
            int len = 0; // 保存读取的字节数
            do{
                len = in.read(date); // 读取内容
                if(len != -1){
                    out.write(date,0,len); // 输错内容
                }
            }while(len != -1); // 没有读完就继续读

        }catch(Exception e){
            throw e;
        }finally {
            if(in != null){
                in.close();
            }
            if(out != null){
                out.close();
            }
        }
        long end = System.currentTimeMillis();

        return (end - start);
    }
}
