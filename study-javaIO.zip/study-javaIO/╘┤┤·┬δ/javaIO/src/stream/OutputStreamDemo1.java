package stream;

import java.io.*;

public class OutputStreamDemo1 {
    public static void main(String[] args) throws IOException {
        // 1. 定义要进行磁盘输出的完整路径
        File file = new File("D:" + File.separator + "parent" + File.separator + "demo.txt" );
        if(file.getParentFile().exists()){
            file.getParentFile().mkdirs(); // 创建父路径
        }
        // 2. 通过子类对OutputStream进行实例化
        OutputStream outputStream = new FileOutputStream(file,true);
        //3.实现数据输出，数据的输出需要将内容变成字节数组
        outputStream.write("\r\n徐京龙好帅".getBytes(),0,5);
        // 4.关闭输出流
        outputStream.close();
    }
}
