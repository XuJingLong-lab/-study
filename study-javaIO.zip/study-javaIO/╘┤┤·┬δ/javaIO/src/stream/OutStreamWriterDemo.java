package stream;

import java.io.*;

public class OutStreamWriterDemo {
    public static void main(String[] args) throws IOException {
        File file = new File("D:" + File.separator + "parent" + File.separator + "demo.txt" );
        if(file.getParentFile().exists()){
            file.getParentFile().mkdirs(); // 创建父路径
        }

        OutputStream outputStream = new FileOutputStream(file);
        Writer writer = new OutputStreamWriter(outputStream);

        writer.write("\r\n徐京龙龙京徐真帅");

        writer.close();

    }

}
