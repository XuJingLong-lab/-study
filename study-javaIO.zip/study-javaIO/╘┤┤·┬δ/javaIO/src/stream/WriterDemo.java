package stream;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class WriterDemo {
    public static void main(String[] args) throws IOException {
        // 1. 定义要进行磁盘输出的完整路径
        File file = new File("D:" + File.separator + "parent" + File.separator + "demo.txt" );
        if(file.getParentFile().exists()){
            file.getParentFile().mkdirs(); // 创建父路径
        }
        // 2.实例化Writer对象
        Writer writer = new FileWriter(file);
        // 3.执行write方法
        writer.write("徐京龙");
        writer.append("徐京龙好帅");
        // 4.关闭
        writer.close();
    }
}
