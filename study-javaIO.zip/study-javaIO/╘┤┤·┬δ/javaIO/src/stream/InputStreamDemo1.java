package stream;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class InputStreamDemo1 {
    public static void main(String[] args) throws IOException {
        // 1.要读的文件路径
        File file = new File("D:" + File.separator + "parent" + File.separator + "demo.txt" );
        if(file.exists()){
            // 2. 实例化InputStream对象
            InputStream inputStream = new FileInputStream(file);
            // 3. 进行读取
            byte[] date = new byte[1024]; // 开辟一块空间进行数据读取
            int len = inputStream.read(date);// 将输入流的内容读到字节数组中
            System.out.println("读到的内容为" + new String(date,0,len)); // 将部分byte[]转换成字符串

            int size = inputStream.available();
            System.out.println("文件大小为：" + size);
            // 4.关闭输入流
            inputStream.close();
        }
    }
}
