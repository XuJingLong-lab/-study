package com.xu.test;

import com.xu.sort.Selection;

import java.util.Arrays;

public class SelectionTest {
    public static void main(String[] args) {
        Integer[] a = new Integer[]{5,4,3,2,1};
        Selection.sort(a);
        System.out.println(Arrays.toString(a));
    }
}
