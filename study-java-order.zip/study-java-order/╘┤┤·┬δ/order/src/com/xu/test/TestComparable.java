package com.xu.test;

import com.xu.entity.Student;

// 2.定义测试类Test，在测试类Test中定义测试方法Comparable getMax(Comparable c1, Comparable c2)完成测试
public class TestComparable {
    public static Comparable getMax(Comparable c1, Comparable c2){

        int result = c1.compareTo(c2);
        // 如果result小于0，那么c1小于c2
        // 如果result 大于0，那么c1大于c2
        // 如果result 等于0，那么c1等于c2
        if(result >= 0){
            return c1;
        }else{
            return c2;
        }
    }


    public static void main(String[] args) {
        Student s1 = new Student();
        s1.setUserName("张三");
        s1.setAge(18);


        Student s2 = new Student();
        s2.setUserName("李四");
        s2.setAge(19);

        Student max = (Student) getMax(s1, s2);
        System.out.println(max.toString());
    }
}
