package com.xu.test;

import com.xu.sort.Quick;

import java.util.Arrays;

public class QuickTest {
    public static void main(String[] args) {
        Integer[] a = new Integer[]{5,4,3,2,1,0};
        Quick.sort(a);
        System.out.println(Arrays.toString(a));
    }
}
