package com.xu.test;

import com.xu.sort.Bubble;

import java.util.Arrays;

public class BubbleTest {
    public static void main(String[] args) {
        Integer[] arr = new Integer[]{6,3,7,5,2,4};
        Bubble.sort(arr);
        System.out.println(Arrays.toString(arr));
    }
}
