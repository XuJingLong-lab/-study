package com.xu.entity;

// 1.定义一个学生类，具有属性userName和age两个给属性，并通过Comparable接口提供比较规则
public class Student implements Comparable<Student>{
    private String userName;
    private int age;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "userName='" + userName + '\'' +
                ", age=" + age +
                '}';
    }

    @Override
    public int compareTo(Student o) {
        // 根据年龄进行比较
        return this.getAge() - o.getAge();
    }
}
