package com.xu.sort;
// 冒泡排序
public class Bubble {
    /*
    * 对数组a中的元素进行排序
    * */
    public static void sort(Comparable[] a){
        // 有多少个元素参与冒泡？初始化为数组最大索引。什么时候停止？只有一个元素的时候。
        for(int i = a.length-1; i > 0; i--){
            for(int j = 0; j < i; j++){
                // 比较索引j和索引j+1处的值
                if(greater(a[j],a[j+1])){
                    exch(a,j,j+1);
                }
            }
        }
    }
    /*
    * 比较v元素是否大于w元素
    * */
    public static boolean greater(Comparable v, Comparable w){

        return v.compareTo(w) > 0;
    }
    /*
    * 数组i和数组j交换位置
    * */
    public static void exch(Comparable[] a, int i, int j){
        Comparable temp;
        temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }
}
