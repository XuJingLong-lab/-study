package com.company.first;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Practices {
    public static void main(String[] args) {
        test5();
    }
    // 练习1：匹配任意多个字符串
    private  static void test1(){
        Pattern pattern = Pattern.compile(".*");
        Matcher matcher = pattern.matcher("abaabaaabaaaab");
        while(matcher.find()){
            System.out.println("找到的字符串是："
            + matcher.group() + " 开始的位置是："
            + matcher.start() + " 结束的位置是："
            + matcher.end());
        }

    }
    // 判断字符串是否匹配 年-月-日 时-分-秒 比如：1998-02-03 10:21:09.100
    private static void test2(){
        boolean b = Pattern.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}.\\d{3}", "1998-02-03 10:21:09.100");
        System.out.println(b);
    }
    // 一个字符串只能由字母、数字、_组成，其长度只能是6-15位
    private static void test3(){
        boolean b = Pattern.matches("\\w{6,15}", "1998-02-03 10:21:09.100");
        System.out.println(b);
    }
    // 验证一个字符串是否是小数
    private static void test4(){
        boolean b = Pattern.matches("\\d+(\\.\\d+)?", "10.3");
        System.out.println(b);
    }
    private static void test5(){
//        boolean b = Pattern.matches(".*foo", "xfooxxxxxxfoo");
//        System.out.println(b);
        Pattern pattern = Pattern.compile("\\w[\\w\\.]*@[\\w\\.]+\\.(com|cn|net)");
        Matcher matcher = pattern.matcher("3399836380@qq.com");
        while(matcher.find()){
            System.out.println("贪婪型匹配的字符串是："+matcher.group()
            +"开始的位置是："+matcher.start()
            +"结束的位置是："+matcher.end());
        }

    }
}
