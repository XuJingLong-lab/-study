package com.company.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestRegex {
    public static void main(String[] args) {
//        System.out.println(isNumber1("123"));
        TestRegex();
    }

    private static boolean isNumber(String str) {

        char[] chars = str.toCharArray();
        for(char c:chars){
            if(c<'0' || c>'9'){
                return false;
            }
        }

        return true;
    }
    private static boolean isNumber1(String str){
        // 使用正则表达式 \d+ 来实现
        // 在java中，正则表达式也是字符串，如何在java中使用正则表达式呢？？？

        // 1.我们需要把字符串类型的正则表达式编译成一个正则模式
        Pattern pattern = Pattern.compile("\\d+");
        // 2.使用这个正则模式去匹配指定的字符串,得到了一个匹配者
        Matcher matcher = pattern.matcher(str);
        // 3.使用匹配者执行匹配
        boolean b = matcher.matches();

        return b;
    }
    private static boolean isNumber2(String str){

        boolean b = Pattern.matches("\\d+", str);

        return b;
    }
    private static void testX(){

        System.out.println(Pattern.matches("a{3}","aaa"));
        System.out.println(Pattern.matches("a{3,}","aaaa"));
        System.out.println(Pattern.matches("a{3,5}","aaa"));
    }
    private static void TestRegex() {
        Pattern pattern = Pattern.compile("a+");
        Matcher matcher = pattern.matcher("babaabaaa");


        while(matcher.find()){
            System.out.println("找到的字符串是：" + matcher.group()
                    + "开始的下标位置是" + matcher.start()
                    + "结束的下标位置是：" + matcher.end());
        }
    }

}
