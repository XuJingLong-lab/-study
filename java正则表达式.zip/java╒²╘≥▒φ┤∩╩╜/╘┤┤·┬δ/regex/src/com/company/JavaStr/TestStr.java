package com.company.JavaStr;

public class TestStr {
    public static void main(String[] args) {
        // String 类中的字符串替换的方法 replace（）
        String str = "Hello world";
        String s = str.replace('l', '_');
        System.out.println(s);
        // String 类中的replaceAll()方法（正则表达式）
        String s1 = str.replaceAll("l", "_"); // 第一个参数是正则表达式
        System.out.println(s1);


        System.out.println("-------例子2---------");
        String str1 = "aa1bb2cc3dd4";
        String s2 = str1.replace("[a-zA-Z]", "_");
        System.out.println("replace替换结果为："+s2);
        String s3 = str1.replaceAll("[a-zA-Z]", "_");
        System.out.println("replaceAll替换结果为："+s3);

        String s4 = str1.replaceFirst("[a-zA-Z]", "_");
        System.out.println("replaceFirst替换结果为："+s4);


        System.out.println("------拆分split---------");

        String ss = "hello world the first day";
        String[] arr = ss.split(" ");
        for(String ss1:arr){
            System.out.println(ss1);
        }
        String[] arr1 = ss.split(" ", 2);
        for(String ss2:arr1){
            System.out.println(ss2);
        }

        System.out.println("-------切割ip地址-----------");
        String ip = "192|168|1|103";
        String[] arr2 = ip.split("\\|");
        for(String ss2:arr2){
            System.out.println(ss2);
        }

        str1 = "aa1bb2cc3dd4";
        // 要求按照数字进行切割
        String[] sss = str1.split("\\d+");
        for(String ss2:sss){
            System.out.println(ss2);
        }

    }
}
